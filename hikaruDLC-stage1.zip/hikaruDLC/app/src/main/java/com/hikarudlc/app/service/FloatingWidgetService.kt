package com.hikarudlc.app.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationCompat
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.lifecycle.setViewTreeViewModelStoreOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import com.hikarudlc.app.MainActivity
import com.hikarudlc.app.R
import com.hikarudlc.app.ui.components.LogoSmall
import com.hikarudlc.app.ui.components.MainMenu
import com.hikarudlc.app.ui.theme.BorderViolet
import com.hikarudlc.app.ui.theme.HikaruDLCTheme
import com.hikarudlc.app.ui.theme.Lavender
import com.hikarudlc.app.ui.theme.Violet
import kotlin.math.hypot

class FloatingWidgetService : Service() {

    private lateinit var windowManager: WindowManager
    private var widgetView: View? = null
    private var menuView: View? = null
    private lateinit var prefs: SharedPreferences

    private var initialX = 0
    private var initialY = 0
    private var initialTouchX = 0f
    private var initialTouchY = 0f
    private var isDragging = false
    private var menuOpen = false
    private var compact = false
    private var fpsValue = 60

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        compact = prefs.getBoolean(KEY_COMPACT, false)
        startForeground(NOTIFICATION_ID, buildNotification())
        showWidget()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_HIDE -> hideWidget()
            ACTION_SHOW -> showWidget()
            ACTION_TOGGLE_COMPACT -> {
                compact = !compact
                prefs.edit().putBoolean(KEY_COMPACT, compact).apply()
                refreshWidget()
            }
            ACTION_STOP -> stopSelf()
        }
        return START_STICKY
    }

    private fun showWidget() {
        if (widgetView != null) return

        val params = createParams()
        val x = prefs.getInt(KEY_X, 40)
        val y = prefs.getInt(KEY_Y, 120)
        params.x = x
        params.y = y

        val composeView = ComposeView(this).apply {
            setViewTreeLifecycleOwner(ServiceLifecycleOwner())
            setContent {
                HikaruDLCTheme {
                    WidgetContent(
                        compact = compact,
                        fps = fpsValue,
                        onLogoClick = { toggleMenu() }
                    )
                }
            }
        }

        // Touch handling for drag vs tap
        composeView.setOnTouchListener { view, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params.x
                    initialY = params.y
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    isDragging = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = event.rawX - initialTouchX
                    val dy = event.rawY - initialTouchY
                    if (!isDragging && hypot(dx.toDouble(), dy.toDouble()) > 12) {
                        isDragging = true
                        closeMenu()
                    }
                    if (isDragging) {
                        params.x = initialX + dx.toInt()
                        params.y = initialY + dy.toInt()
                        windowManager.updateViewLayout(view, params)
                    }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    if (isDragging) {
                        prefs.edit()
                            .putInt(KEY_X, params.x)
                            .putInt(KEY_Y, params.y)
                            .apply()
                    } else {
                        // Tap — open/close menu (handled via logo click in Compose)
                    }
                    isDragging = false
                    true
                }
                else -> false
            }
        }

        widgetView = composeView
        windowManager.addView(composeView, params)
    }

    private fun hideWidget() {
        closeMenu()
        widgetView?.let {
            try { windowManager.removeView(it) } catch (_: Exception) {}
        }
        widgetView = null
    }

    private fun refreshWidget() {
        hideWidget()
        showWidget()
    }

    private fun toggleMenu() {
        if (menuOpen) closeMenu() else openMenu()
    }

    private fun openMenu() {
        if (menuView != null) return
        menuOpen = true

        val widgetParams = widgetView?.layoutParams as? WindowManager.LayoutParams ?: return
        val menuParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = widgetParams.x
            y = widgetParams.y + 90
        }

        val composeView = ComposeView(this).apply {
            setViewTreeLifecycleOwner(ServiceLifecycleOwner())
            setContent {
                HikaruDLCTheme {
                    MainMenu(modifier = Modifier.width(270.dp))
                }
            }
        }
        menuView = composeView
        windowManager.addView(composeView, menuParams)
    }

    private fun closeMenu() {
        menuOpen = false
        menuView?.let {
            try { windowManager.removeView(it) } catch (_: Exception) {}
        }
        menuView = null
    }

    private fun createParams(): WindowManager.LayoutParams {
        val w = if (compact) 220 else 330
        val h = if (compact) 60 else 80
        return WindowManager.LayoutParams(
            (w * resources.displayMetrics.density).toInt(),
            (h * resources.displayMetrics.density).toInt(),
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
        }
    }

    private fun overlayType(): Int {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }
    }

    private fun buildNotification(): Notification {
        val channelId = "hikaru_widget"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                getString(R.string.notification_channel_name),
                NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
        val pending = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, channelId)
            .setContentTitle(getString(R.string.notification_title))
            .setContentText(getString(R.string.notification_text))
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentIntent(pending)
            .setOngoing(true)
            .build()
    }

    override fun onDestroy() {
        hideWidget()
        super.onDestroy()
    }

    companion object {
        const val ACTION_HIDE = "com.hikarudlc.app.HIDE"
        const val ACTION_SHOW = "com.hikarudlc.app.SHOW"
        const val ACTION_TOGGLE_COMPACT = "com.hikarudlc.app.TOGGLE_COMPACT"
        const val ACTION_STOP = "com.hikarudlc.app.STOP"
        private const val NOTIFICATION_ID = 1001
        private const val PREFS = "hikaru_widget"
        private const val KEY_X = "x"
        private const val KEY_Y = "y"
        private const val KEY_COMPACT = "compact"

        fun start(context: Context) {
            val intent = Intent(context, FloatingWidgetService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun sendAction(context: Context, action: String) {
            val intent = Intent(context, FloatingWidgetService::class.java).apply {
                this.action = action
            }
            context.startService(intent)
        }
    }
}

/**
 * Minimal lifecycle owner so ComposeView works inside a Service.
 */
private class ServiceLifecycleOwner : androidx.lifecycle.LifecycleOwner,
    androidx.lifecycle.ViewModelStoreOwner,
    androidx.savedstate.SavedStateRegistryOwner {

    private val lifecycleRegistry = androidx.lifecycle.LifecycleRegistry(this)
    private val store = androidx.lifecycle.ViewModelStore()
    private val savedStateRegistryController =
        androidx.savedstate.SavedStateRegistryController.create(this)

    init {
        savedStateRegistryController.performRestore(null)
        lifecycleRegistry.currentState = androidx.lifecycle.Lifecycle.State.RESUMED
    }

    override val lifecycle: androidx.lifecycle.Lifecycle get() = lifecycleRegistry
    override val viewModelStore: androidx.lifecycle.ViewModelStore get() = store
    override val savedStateRegistry: androidx.savedstate.SavedStateRegistry
        get() = savedStateRegistryController.savedStateRegistry
}

@Composable
private fun WidgetContent(
    compact: Boolean,
    fps: Int,
    onLogoClick: () -> Unit
) {
    val height = if (compact) 60.dp else 80.dp
    val brandSize = if (compact) 18.sp else 24.sp
    val fpsSize = if (compact) 14.sp else 18.sp

    Row(
        modifier = Modifier
            .height(height)
            .clip(RoundedCornerShape(40.dp))
            .background(
                Brush.verticalGradient(
                    listOf(
                        Color.White.copy(alpha = 0.16f),
                        Color(0x1E9696AA),
                        Color.White.copy(alpha = 0.07f)
                    )
                )
            )
            .border(1.5.dp, Color(0xBFE1D7FF), RoundedCornerShape(40.dp))
            .padding(horizontal = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Logo section
        Box(
            modifier = Modifier
                .weight(0.25f)
                .fillMaxHeight()
                .clickable { onLogoClick() },
            contentAlignment = Alignment.Center
        ) {
            LogoSmall(size = if (compact) 32.dp else 40.dp)
        }

        // Separator
        Box(
            Modifier
                .width(2.dp)
                .fillMaxHeight(0.6f)
                .background(
                    Brush.verticalGradient(
                        listOf(Color.Transparent, Color(0xE6F0EBFF), Color.Transparent)
                    )
                )
        )

        // Brand
        Box(
            modifier = Modifier
                .weight(0.54f)
                .fillMaxHeight(),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "hikaruDLC",
                color = Color.White,
                fontSize = brandSize,
                fontWeight = FontWeight.ExtraBold,
                letterSpacing = (-0.5).sp
            )
        }

        // Separator
        Box(
            Modifier
                .width(2.dp)
                .fillMaxHeight(0.6f)
                .background(
                    Brush.verticalGradient(
                        listOf(Color.Transparent, Color(0xE6F0EBFF), Color.Transparent)
                    )
                )
        )

        // FPS
        Column(
            modifier = Modifier
                .weight(0.21f)
                .fillMaxHeight(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = "fps",
                color = Color(0xFFF1EDFF),
                fontSize = (fpsSize.value * 0.7f).sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = fps.toString(),
                color = Color(0xFFF1EDFF),
                fontSize = fpsSize,
                fontWeight = FontWeight.ExtraBold
            )
        }
    }
}

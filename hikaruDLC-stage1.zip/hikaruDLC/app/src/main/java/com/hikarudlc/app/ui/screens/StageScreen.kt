package com.hikarudlc.app.ui.screens

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.hikarudlc.app.service.FloatingWidgetService
import com.hikarudlc.app.ui.theme.BorderViolet
import com.hikarudlc.app.ui.theme.TextMuted

@Composable
fun StageScreen() {
    val context = LocalContext.current
    var showPermissionDialog by remember { mutableStateOf(false) }
    var widgetVisible by remember { mutableStateOf(true) }

    fun canDrawOverlays(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Settings.canDrawOverlays(context)
        } else true
    }

    fun startWidget() {
        if (canDrawOverlays()) {
            FloatingWidgetService.start(context)
            widgetVisible = true
        } else {
            showPermissionDialog = true
        }
    }

    LaunchedEffect(Unit) {
        startWidget()
    }

    if (showPermissionDialog) {
        AlertDialog(
            onDismissRequest = { showPermissionDialog = false },
            title = { Text("Разрешение на показ поверх окон") },
            text = {
                Text(
                    "Чтобы плавающий виджет работал поверх игры Granny, нужно разрешить отображение поверх других приложений.\n\n" +
                            "Нажми «Открыть настройки» → найди hikaruDLC → включи переключатель."
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    showPermissionDialog = false
                    val intent = Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:${context.packageName}")
                    )
                    context.startActivity(intent)
                }) {
                    Text("Открыть настройки")
                }
            },
            dismissButton = {
                TextButton(onClick = { showPermissionDialog = false }) {
                    Text("Позже")
                }
            }
        )
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.radialGradient(
                    colors = listOf(
                        Color(0xFF4A4B57),
                        Color(0xFF26272E),
                        Color(0xFF18181C)
                    )
                )
            )
    ) {
        Column(
            modifier = Modifier.align(Alignment.Center),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "DEMO BACKDROP",
                color = Color(0x52E6E2FA),
                fontSize = 11.sp,
                letterSpacing = 3.sp,
                textAlign = TextAlign.Center
            )
            Text(
                text = "THE GAME",
                color = Color(0x52E6E2FA),
                fontSize = 11.sp,
                letterSpacing = 3.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(top = 4.dp)
            )
            Text(
                text = "WOULD BE HERE",
                color = Color(0x52E6E2FA),
                fontSize = 11.sp,
                letterSpacing = 3.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(top = 4.dp)
            )
        }

        // Demo control bar
        Row(
            modifier = Modifier
                .align(Alignment.BottomStart)
                .navigationBarsPadding()
                .padding(14.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            DemoButton(
                text = if (widgetVisible) "HIDE WIDGET" else "SHOW WIDGET",
                onClick = {
                    if (widgetVisible) {
                        FloatingWidgetService.sendAction(context, FloatingWidgetService.ACTION_HIDE)
                        widgetVisible = false
                    } else {
                        startWidget()
                    }
                }
            )
            DemoButton(
                text = "COMPACT",
                onClick = {
                    FloatingWidgetService.sendAction(
                        context,
                        FloatingWidgetService.ACTION_TOGGLE_COMPACT
                    )
                }
            )
        }
    }
}

@Composable
private fun DemoButton(
    text: String,
    onClick: () -> Unit
) {
    Text(
        text = text,
        color = Color(0xCCEBE8FA),
        fontSize = 11.sp,
        letterSpacing = 1.2.sp,
        fontWeight = FontWeight.Medium,
        modifier = Modifier
            .clip(RoundedCornerShape(12.dp))
            .background(Color.White.copy(alpha = 0.06f))
            .border(1.dp, Color.White.copy(alpha = 0.14f), RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 8.dp)
    )
}

package com.hikarudlc.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.hikarudlc.app.ui.theme.BorderViolet
import com.hikarudlc.app.ui.theme.Violet
import com.hikarudlc.app.ui.theme.WhiteSoft

enum class ActivateState {
    Idle, Verifying, Granted, Error
}

@Composable
fun ActivateButton(
    state: ActivateState,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val enabled = state == ActivateState.Idle || state == ActivateState.Error

    val text = when (state) {
        ActivateState.Idle, ActivateState.Error -> "ACTIVATE"
        ActivateState.Verifying -> "VERIFYING"
        ActivateState.Granted -> "ACCESS GRANTED"
    }

    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(52.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        Color.White.copy(alpha = 0.09f),
                        Color(0x2E7864C8),
                        Color(0x528F7BFF)
                    )
                )
            )
            .border(
                width = 1.dp,
                color = BorderViolet,
                shape = RoundedCornerShape(16.dp)
            )
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = text,
                color = WhiteSoft,
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold,
                letterSpacing = 3.6.sp
            )
            when (state) {
                ActivateState.Verifying -> {
                    CircularProgressIndicator(
                        modifier = Modifier.size(16.dp),
                        color = Color.White,
                        strokeWidth = 2.dp
                    )
                }
                ActivateState.Granted -> {
                    Text(text = "✓", color = Color.White, fontSize = 16.sp)
                }
                else -> {
                    Text(text = "→", color = Color.White, fontSize = 16.sp)
                }
            }
        }
    }
}

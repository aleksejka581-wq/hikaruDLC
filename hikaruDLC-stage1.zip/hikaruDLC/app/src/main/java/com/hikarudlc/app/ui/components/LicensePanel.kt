package com.hikarudlc.app.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.hikarudlc.app.ui.theme.BorderViolet
import com.hikarudlc.app.ui.theme.ErrorRed
import com.hikarudlc.app.ui.theme.Lavender
import com.hikarudlc.app.ui.theme.TextMuted
import com.hikarudlc.app.ui.theme.Violet

@Composable
fun LicensePanel(
    keyValue: String,
    onKeyChange: (String) -> Unit,
    activateState: ActivateState,
    statusKind: StatusKind,
    statusText: String,
    isError: Boolean,
    onActivate: () -> Unit,
    modifier: Modifier = Modifier
) {
    val appear = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        appear.animateTo(1f, tween(900, delayMillis = 150))
    }

    val borderColor = when {
        activateState == ActivateState.Granted -> Color(0xB3EBE6FF)
        isError -> ErrorRed.copy(alpha = 0.4f)
        else -> BorderViolet
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .alpha(appear.value)
            .clip(RoundedCornerShape(30.dp))
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        Color.White.copy(alpha = 0.085f),
                        Color.White.copy(alpha = 0.025f),
                        Color.White.copy(alpha = 0.04f)
                    )
                )
            )
            .border(1.dp, borderColor, RoundedCornerShape(30.dp))
            .padding(horizontal = 40.dp, vertical = 34.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        LogoMark(size = 58.dp)

        Spacer(Modifier.height(8.dp))

        Text(
            text = buildAnnotatedString {
                withStyle(
                    SpanStyle(
                        brush = Brush.verticalGradient(
                            listOf(Color(0xFFFBFAFF), Color(0xFFBDB9CC), Color(0xFF8D8A9E))
                        ),
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 48.sp
                    )
                ) {
                    append("hikaru")
                }
                withStyle(
                    SpanStyle(
                        brush = Brush.verticalGradient(
                            listOf(Color(0xFFCFCBE0), Color(0xFF7F7B92))
                        ),
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 48.sp
                    )
                ) {
                    append("DLC")
                }
            },
            textAlign = TextAlign.Center
        )

        Spacer(Modifier.height(10.dp))

        Text(
            text = "LICENSE VERIFICATION",
            color = TextMuted,
            fontSize = 11.sp,
            letterSpacing = 3.5.sp
        )

        Spacer(Modifier.height(34.dp))

        KeyInput(
            value = keyValue,
            onValueChange = onKeyChange,
            isError = isError,
            enabled = activateState != ActivateState.Verifying && activateState != ActivateState.Granted,
            onDone = onActivate
        )

        Spacer(Modifier.height(20.dp))

        ActivateButton(
            state = activateState,
            onClick = onActivate
        )

        Spacer(Modifier.height(20.dp))

        ActivationStatus(
            kind = statusKind,
            text = statusText
        )
    }
}

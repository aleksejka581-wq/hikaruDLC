package com.hikarudlc.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val DarkColorScheme = darkColorScheme(
    primary = Violet,
    secondary = Lavender,
    background = Bg,
    surface = Bg,
    onPrimary = Silver,
    onSecondary = Silver,
    onBackground = Silver,
    onSurface = Silver,
    error = ErrorRed
)

@Composable
fun HikaruDLCTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography = Typography,
        content = content
    )
}

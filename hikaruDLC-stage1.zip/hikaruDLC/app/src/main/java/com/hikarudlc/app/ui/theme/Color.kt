package com.hikarudlc.app.ui.theme

import androidx.compose.ui.graphics.Color

val Bg = Color(0xFF121214)
val BgDeep = Color(0xFF101012)
val Violet = Color(0xFF8F7BFF)
val Lavender = Color(0xFFC9BFFF)
val Silver = Color(0xFFE9E7F2)
val ErrorRed = Color(0xFFFF6B7A)
val PanelBg = Color(0x16FFFFFF)
val FieldBg = Color(0x8C141418)
val TextMuted = Color(0x9ED7D2EB)
val TextDim = Color(0x66D7D2EB)
val GlowViolet = Color(0xA08F7BFF)
val BorderViolet = Color(0x61CDC3FF)
val WhiteSoft = Color(0xF2F2EFFC)

package com.hikarudlc.app.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.hikarudlc.app.ui.theme.Lavender
import com.hikarudlc.app.ui.theme.Violet

/**
 * Approximates the angular logo mark from the HTML SVG.
 */
@Composable
fun LogoMark(
    modifier: Modifier = Modifier,
    size: Dp = 58.dp
) {
    Canvas(modifier = modifier.size(size)) {
        val w = this.size.width
        val h = this.size.height
        val s = w / 64f

        // Left slanted facet
        val leftPath = Path().apply {
            moveTo(5f * s, 58f * s)
            lineTo(17f * s, 22f * s)
            lineTo(27f * s, 17f * s)
            lineTo(15f * s, 53f * s)
            close()
        }
        drawPath(
            path = leftPath,
            brush = Brush.linearGradient(
                colors = listOf(Color.White, Color(0xFFCFC8EE), Color(0xFF7F6DF0)),
                start = Offset(5f * s, 58f * s),
                end = Offset(27f * s, 17f * s)
            )
        )

        // Highlight on left
        val leftHighlight = Path().apply {
            moveTo(17f * s, 22f * s)
            lineTo(27f * s, 17f * s)
            lineTo(24f * s, 26f * s)
            close()
        }
        drawPath(leftHighlight, Color.White.copy(alpha = 0.7f))

        // Right H-bolt facet
        val rightPath = Path().apply {
            moveTo(31f * s, 5f * s)
            lineTo(43f * s, 9f * s)
            lineTo(39f * s, 26f * s)
            lineTo(56f * s, 19f * s)
            lineTo(46f * s, 59f * s)
            lineTo(34f * s, 54f * s)
            lineTo(38f * s, 39f * s)
            lineTo(22f * s, 46f * s)
            lineTo(27f * s, 28f * s)
            lineTo(36f * s, 23f * s)
            close()
        }
        drawPath(
            path = rightPath,
            brush = Brush.linearGradient(
                colors = listOf(Color(0xFFF5F2FF), Color(0xFFA99CF5), Color(0xFF6A56E0)),
                start = Offset(56f * s, 19f * s),
                end = Offset(22f * s, 46f * s)
            )
        )

        // Small highlights
        val topHighlight = Path().apply {
            moveTo(31f * s, 5f * s)
            lineTo(43f * s, 9f * s)
            lineTo(36f * s, 23f * s)
            close()
        }
        drawPath(topHighlight, Color.White.copy(alpha = 0.75f))
    }
}

@Composable
fun LogoSmall(
    modifier: Modifier = Modifier,
    size: Dp = 44.dp
) {
    LogoMark(modifier = modifier, size = size)
}

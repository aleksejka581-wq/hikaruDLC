package com.hikarudlc.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import com.hikarudlc.app.ui.screens.ActivationScreen
import com.hikarudlc.app.ui.screens.StageScreen
import com.hikarudlc.app.ui.theme.HikaruDLCTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            HikaruDLCTheme {
                var activated by remember { mutableStateOf(false) }

                if (activated) {
                    StageScreen()
                } else {
                    ActivationScreen(
                        onActivated = { activated = true }
                    )
                }
            }
        }
    }
}

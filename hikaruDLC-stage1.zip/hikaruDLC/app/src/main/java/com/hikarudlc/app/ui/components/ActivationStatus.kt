package com.hikarudlc.app.ui.components

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.hikarudlc.app.ui.theme.ErrorRed
import com.hikarudlc.app.ui.theme.Lavender
import com.hikarudlc.app.ui.theme.TextMuted
import com.hikarudlc.app.ui.theme.Violet

enum class StatusKind {
    Idle, Verifying, Error, Ok
}

@Composable
fun ActivationStatus(
    kind: StatusKind,
    text: String,
    modifier: Modifier = Modifier
) {
    val color = when (kind) {
        StatusKind.Error -> Color(0xFFFFB3BC)
        StatusKind.Ok -> Color(0xFFEFEAFF)
        else -> TextMuted
    }
    val dotColor = when (kind) {
        StatusKind.Error -> ErrorRed
        StatusKind.Ok -> Color(0xFFE6E0FF)
        else -> Violet
    }

    val infinite = rememberInfiniteTransition(label = "pulse")
    val alpha by infinite.animateFloat(
        initialValue = 1f,
        targetValue = 0.35f,
        animationSpec = infiniteRepeatable(
            animation = tween(1000),
            repeatMode = RepeatMode.Reverse
        ),
        label = "alpha"
    )

    Row(
        modifier = modifier,
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Box(
            modifier = Modifier
                .size(8.dp)
                .alpha(if (kind == StatusKind.Verifying) alpha else 1f)
                .background(dotColor, CircleShape)
        )
        Text(
            text = text,
            color = color,
            fontSize = 11.5.sp
        )
    }
}

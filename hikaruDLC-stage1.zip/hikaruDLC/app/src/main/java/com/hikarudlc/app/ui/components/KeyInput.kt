package com.hikarudlc.app.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.hikarudlc.app.R
import com.hikarudlc.app.ui.theme.BorderViolet
import com.hikarudlc.app.ui.theme.ErrorRed
import com.hikarudlc.app.ui.theme.FieldBg
import com.hikarudlc.app.ui.theme.Lavender
import com.hikarudlc.app.ui.theme.TextDim
import com.hikarudlc.app.ui.theme.TextMuted
import com.hikarudlc.app.ui.theme.Violet

@Composable
fun KeyInput(
    value: String,
    onValueChange: (String) -> Unit,
    isError: Boolean,
    enabled: Boolean,
    onDone: () -> Unit,
    modifier: Modifier = Modifier
) {
    var visible by remember { mutableStateOf(false) }
    val shake = remember { Animatable(0f) }

    LaunchedEffect(isError) {
        if (isError) {
            shake.snapTo(0f)
            shake.animateTo(1f, tween(50))
            shake.animateTo(-1f, tween(50))
            shake.animateTo(1f, tween(50))
            shake.animateTo(0f, tween(50))
        }
    }

    val borderColor = when {
        isError -> ErrorRed.copy(alpha = 0.6f)
        else -> Color.White.copy(alpha = 0.14f)
    }

    Row(
        modifier = modifier
            .fillMaxWidth()
            .height(48.dp)
            .padding(horizontal = shake.value.dp * 4)
            .clip(RoundedCornerShape(16.dp))
            .background(FieldBg)
            .border(
                width = 1.dp,
                color = borderColor,
                shape = RoundedCornerShape(16.dp)
            )
            .padding(horizontal = 16.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Lock icon (simple text fallback if no drawable)
        Text(
            text = "🔒",
            fontSize = 16.sp,
            color = TextMuted
        )

        Box(modifier = Modifier.weight(1f)) {
            if (value.isEmpty()) {
                Text(
                    text = "Enter your access key",
                    color = TextDim,
                    fontSize = 14.sp
                )
            }
            BasicTextField(
                value = value,
                onValueChange = onValueChange,
                enabled = enabled,
                singleLine = true,
                visualTransformation = if (visible) VisualTransformation.None else PasswordVisualTransformation(),
                textStyle = TextStyle(
                    color = Color(0xFFE9E7F2),
                    fontSize = 14.sp,
                    letterSpacing = 0.3.sp
                ),
                cursorBrush = SolidColor(Violet),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
                keyboardActions = KeyboardActions(onGo = { onDone() }),
                modifier = Modifier.fillMaxWidth()
            )
        }

        Box(
            modifier = Modifier
                .size(34.dp)
                .clip(RoundedCornerShape(10.dp))
                .clickable(enabled = enabled) { visible = !visible },
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = if (visible) "👁" else "👁‍🗨",
                fontSize = 16.sp,
                color = if (visible) Lavender else TextMuted
            )
        }
    }
}

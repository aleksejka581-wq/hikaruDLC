package com.hikarudlc.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.hikarudlc.app.ui.theme.BorderViolet
import com.hikarudlc.app.ui.theme.Lavender
import com.hikarudlc.app.ui.theme.TextMuted

/**
 * Placeholder MainMenu.
 * Real layout will be added when the menu reference is provided (Stage 2).
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun MainMenu(
    modifier: Modifier = Modifier
) {
    val categories = listOf(
        "PLAYER", "GRANNY", "ITEMS",
        "WORLD", "GAME", "VISUALS",
        "TELEPORT", "RAGE", "SYSTEM"
    )

    Column(
        modifier = modifier
            .clip(RoundedCornerShape(22.dp))
            .background(
                Brush.verticalGradient(
                    listOf(
                        Color.White.copy(alpha = 0.09f),
                        Color.White.copy(alpha = 0.03f)
                    )
                )
            )
            .border(1.dp, BorderViolet, RoundedCornerShape(22.dp))
            .padding(18.dp)
    ) {
        Text(
            text = "MAIN MENU",
            color = Lavender,
            fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold,
            letterSpacing = 2.8.sp
        )
        Text(
            text = "Placeholder. The real layout will be added when the menu reference is provided.",
            color = TextMuted,
            fontSize = 11.5.sp,
            modifier = Modifier.padding(top = 8.dp)
        )

        FlowRow(
            modifier = Modifier.padding(top = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            categories.forEach { cat ->
                Text(
                    text = cat,
                    color = Color(0xB3EBE8FA),
                    fontSize = 10.sp,
                    letterSpacing = 1.4.sp,
                    modifier = Modifier
                        .clip(RoundedCornerShape(9.dp))
                        .border(1.dp, Color.White.copy(alpha = 0.14f), RoundedCornerShape(9.dp))
                        .padding(horizontal = 9.dp, vertical = 5.dp)
                )
            }
        }
    }
}

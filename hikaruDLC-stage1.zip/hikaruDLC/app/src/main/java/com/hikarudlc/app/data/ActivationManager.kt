package com.hikarudlc.app.data

import kotlinx.coroutines.delay

/**
 * Local license check for demo.
 * Later this class can be replaced with a real network call to a license server.
 * Do NOT store real secrets in the app binary.
 */
class ActivationManager {

    data class Result(
        val ok: Boolean,
        val reason: String? = null
    )

    /**
     * Verifies the key locally.
     * Currently accepts only the demo key "hikaru-1".
     * Architecture allows easy replacement with server verification.
     */
    suspend fun verify(key: String): Result {
        // Simulated network/work delay
        delay(900)

        return if (key == DEMO_KEY) {
            Result(ok = true)
        } else {
            Result(ok = false, reason = "invalid")
        }
    }

    companion object {
        // Demo only. In production this constant should not exist.
        // Real keys must be validated on a server.
        private const val DEMO_KEY = "hikaru-1"
    }
}

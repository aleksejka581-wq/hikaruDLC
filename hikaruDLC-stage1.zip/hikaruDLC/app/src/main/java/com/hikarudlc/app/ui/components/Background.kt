package com.hikarudlc.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.offset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.hikarudlc.app.ui.theme.Bg
import com.hikarudlc.app.ui.theme.BgDeep

@Composable
fun AppBackground(
    modifier: Modifier = Modifier,
    showBigText: Boolean = true,
    content: @Composable () -> Unit
) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(Color(0xFF1A1A1D), BgDeep)
                )
            )
    ) {
        // Soft radial glows
        Box(
            Modifier
                .fillMaxSize()
                .background(
                    Brush.radialGradient(
                        colors = listOf(Color(0x47787882), Color.Transparent),
                        center = Offset(0.5f, 0f),
                        radius = 900f
                    )
                )
        )
        Box(
            Modifier
                .fillMaxSize()
                .background(
                    Brush.radialGradient(
                        colors = listOf(Color(0x295A5A64), Color.Transparent),
                        center = Offset(0.5f, 1f),
                        radius = 800f
                    )
                )
        )

        if (showBigText) {
            Text(
                text = "hikaruDLC",
                color = Color.White.copy(alpha = 0.055f),
                fontSize = 120.sp,
                fontWeight = FontWeight.ExtraBold,
                letterSpacing = (-2).sp,
                modifier = Modifier
                    .align(Alignment.Center)
                    .offset(y = (-20).dp)
            )
        }

        content()
    }
}

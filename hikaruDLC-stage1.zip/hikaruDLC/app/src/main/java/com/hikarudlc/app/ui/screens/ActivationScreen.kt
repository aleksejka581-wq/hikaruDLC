package com.hikarudlc.app.ui.screens

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.hikarudlc.app.data.ActivationManager
import com.hikarudlc.app.ui.components.ActivateState
import com.hikarudlc.app.ui.components.AppBackground
import com.hikarudlc.app.ui.components.LicensePanel
import com.hikarudlc.app.ui.components.StatusKind
import com.hikarudlc.app.ui.theme.Lavender
import com.hikarudlc.app.ui.theme.TextMuted
import com.hikarudlc.app.ui.theme.Violet
import kotlinx.coroutines.launch

@Composable
fun ActivationScreen(
    onActivated: () -> Unit
) {
    val manager = remember { ActivationManager() }
    val scope = rememberCoroutineScope()

    var key by remember { mutableStateOf("") }
    var activateState by remember { mutableStateOf(ActivateState.Idle) }
    var statusKind by remember { mutableStateOf(StatusKind.Idle) }
    var statusText by remember { mutableStateOf("Waiting for key...") }
    var isError by remember { mutableStateOf(false) }

    fun clearError() {
        if (activateState == ActivateState.Verifying) return
        isError = false
        statusKind = StatusKind.Idle
        statusText = "Waiting for key..."
    }

    fun activate() {
        if (activateState == ActivateState.Verifying || activateState == ActivateState.Granted) return
        if (key.isEmpty()) {
            isError = true
            statusKind = StatusKind.Error
            statusText = "Please enter your access key"
            activateState = ActivateState.Error
            return
        }

        activateState = ActivateState.Verifying
        isError = false
        statusKind = StatusKind.Verifying
        statusText = "Verifying key..."

        scope.launch {
            val result = manager.verify(key)
            if (result.ok) {
                activateState = ActivateState.Granted
                statusKind = StatusKind.Ok
                statusText = "Access granted"
                // Small delay so user sees the success state
                kotlinx.coroutines.delay(1200)
                onActivated()
            } else {
                activateState = ActivateState.Error
                isError = true
                statusKind = StatusKind.Error
                statusText = "Invalid access key"
            }
        }
    }

    AppBackground(showBigText = true) {
        // Top-right corner
        Row(
            modifier = Modifier
                .align(Alignment.TopEnd)
                .statusBarsPadding()
                .padding(top = 22.dp, end = 30.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                Modifier
                    .padding(end = 10.dp)
                    .then(Modifier)
            ) {
                androidx.compose.foundation.Canvas(Modifier.padding(0.dp)) {}
            }
            Text(
                text = "●",
                color = Violet,
                fontSize = 10.sp,
                modifier = Modifier.padding(end = 8.dp)
            )
            Text(
                text = "DEMO MODE",
                color = Lavender,
                fontSize = 10.sp,
                letterSpacing = 2.sp,
                fontWeight = FontWeight.Medium
            )
            Text(
                text = "  |  ",
                color = TextMuted.copy(alpha = 0.5f),
                fontSize = 10.sp
            )
            Text(
                text = "UI ONLY",
                color = TextMuted,
                fontSize = 10.sp,
                letterSpacing = 2.sp
            )
        }

        // Bottom-left corner
        Column(
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(start = 46.dp, bottom = 40.dp)
        ) {
            Text(
                text = "🔑  hikaruDLC",
                color = Color(0xB3EBE8FA),
                fontSize = 11.sp,
                letterSpacing = 1.sp
            )
            Text(
                text = "ACCESS REQUIRED",
                color = Color(0x99EBE8FA),
                fontSize = 11.sp,
                letterSpacing = 1.5.sp,
                modifier = Modifier.padding(top = 6.dp)
            )
        }

        // Center panel
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 24.dp),
            contentAlignment = Alignment.Center
        ) {
            LicensePanel(
                keyValue = key,
                onKeyChange = {
                    key = it
                    if (isError) clearError()
                },
                activateState = activateState,
                statusKind = statusKind,
                statusText = statusText,
                isError = isError,
                onActivate = { activate() },
                modifier = Modifier.fillMaxWidth(0.95f)
            )
        }
    }
}

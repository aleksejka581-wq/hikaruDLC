# Keep Compose and service classes
-keep class com.hikarudlc.app.** { *; }

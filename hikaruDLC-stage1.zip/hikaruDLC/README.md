# hikaruDLC — Android (Этап 1)

Нативное приложение на **Kotlin + Jetpack Compose**, повторяющее UI из HTML-демо.

## Что уже есть

- Экран активации (License Verification) — стекло, свечение, логотип, поле ключа, кнопка ACTIVATE, статусы
- Локальная проверка ключа `hikaru-1` (архитектура готова к замене на сервер)
- Плавающий виджет через `SYSTEM_ALERT_WINDOW` + foreground-сервис
  - перетаскивание
  - отличие тапа от перетаскивания
  - сохранение позиции
  - компактный режим
  - запрос разрешения с объяснением
- Компоненты разделены: Background, Logo, LicensePanel, KeyInput, ActivateButton, ActivationStatus, ActivationManager, FloatingWidget, MainMenu (заглушка)
- FPS — условное значение (60)
- GitHub Actions собирает debug и release APK

## Как собрать APK с телефона (через GitHub)

### 1. Создай репозиторий

1. Открой браузер → github.com
2. Войди в аккаунт
3. Нажми **New repository**
4. Имя: `hikaruDLC` (или любое)
5. Public → Create repository

### 2. Загрузи файлы

**Вариант А (проще с телефона):**

1. Скачай весь проект как ZIP (если я дам ссылку) или скопируй папки
2. В репозитории нажми **Add file → Upload files**
3. Загрузи **все** файлы и папки из проекта (сохраняя структуру)
4. Commit changes

**Вариант Б (через GitHub app / termux / MT Manager):**

Если умеешь пользоваться git — сделай `git init`, `git add .`, `git commit`, `git push`.

### 3. Дождись сборки

1. Открой вкладку **Actions**
2. Выбери workflow **Build APK**
3. Дождись зелёной галочки (2–5 минут)

### 4. Скачай APK

1. В успешном запуске Actions открой **Artifacts**
2. Скачай `hikaruDLC-debug` (или release)
3. Распакуй ZIP → установи APK на телефон
4. Разреши установку из неизвестных источников, если попросит

### 5. Первый запуск

1. Введи ключ: `hikaru-1`
2. Нажми ACTIVATE
3. Разреши «Показывать поверх других приложений»
4. Появится плавающий виджет

## Структура проекта

```
hikaruDLC/
├── .github/workflows/build.yml
├── app/
│   ├── build.gradle.kts
│   ├── src/main/
│   │   ├── AndroidManifest.xml
│   │   ├── java/com/hikarudlc/app/
│   │   │   ├── MainActivity.kt
│   │   │   ├── data/ActivationManager.kt
│   │   │   ├── service/FloatingWidgetService.kt
│   │   │   └── ui/
│   │   │       ├── theme/
│   │   │       ├── components/
│   │   │       └── screens/
│   │   └── res/
├── build.gradle.kts
├── settings.gradle.kts
└── gradle.properties
```

## Важно

- Это **только UI** (Этап 1). Связи с игрой Granny пока нет.
- Меню функций — Этап 2 (ждём референс).
- Исследование способов влияния на игру — Этап 3.
